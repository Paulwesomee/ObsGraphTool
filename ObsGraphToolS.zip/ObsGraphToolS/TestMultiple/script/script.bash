#!/bin/bash


echo "le dossier est $1"
cd $1
k=0
for i in *
do
if [ -f $i ]
then
echo ""
echo "  $i"
var1=$(pwd)

var=$i
model="$var1/$i"
#echo "$model"
lenght=${#var}
nomodel=${var:0:($lenght-4)}
Obs="$var1/Obs/Obs_$nomodel"
#echo $Obs
Fplace="$var1/Fplace/Fplace_$nomodel"
#echo $Fplace

echo "../../ObsGraph $model $Obs $Fplace 1"
res=$(../../ObsGraph $model $Obs $Fplace 1)
echo $res
a=$(expr index "$res" \#)
a2=${res:a}
#echo "ALOOO $a2"
a2=${a2:23}
#echo "CACHOOO $a2"
b=$(expr index "$a2" M)
tt=$(expr $b - 3)
a3=${a2:0:tt}
#echo "FAHHHH $a3"
echo "temps = !$a3!"
temps[k]=$a3


aa=$(expr index "$res" \*)
aa2=${res:aa}
aa=$(expr index "$aa2" \*)
aa2=${aa2:0:aa}
#echo "graph : $aa2"
aa=$(expr index "$aa2" :)
aa2=${aa2:aa+1}
#echo "dici on va retirer noeud $aa2"
aa=$(expr index "$aa2" N)
noeuds=${aa2:0:aa-3}
echo "noeuds: !$noeuds!"
N[k]=$noeuds
aa2=${aa2:aa+1}
aa=$(expr index "$aa2" :)
aa2=${aa2:aa+1}
aa=$(expr index "$aa2" \*)
arcs=${aa2:0:aa-1}
echo "arcs: !$arcs!"
A[k]=$arcs
let k=$k+1
echo "Model $k : DONE"
echo ""
fi
done

sommeT=0
sommeA=0
sommeN=0
for ((j=0;j<$k;j++))
do

s=${temps[j]}
l=.1
#echo "printf '%.20f' $s"
#s=`printf '%.20f' $s`
sommeT=$(echo "$sommeT+$s" |bc)

n=${N[j]}

sommeN=$(echo "$sommeN+$n" |bc)

a=${A[j]}

sommeA=$(echo "$sommeA+$a" |bc)
done

#echo "hhh $somme"
avgT=$(echo "scale=9;$sommeT/$k" |bc)
avgA=$(echo "$sommeA/$k" |bc)
avgN=$(echo "$sommeN/$k" |bc)
echo "Analyse de $k process"
echo "Le temps moyen pour construire OG = $avgT (seconde)"
echo "Le nombre moyen d'arcs pour OG = $avgA"
echo "Le nombre moyen de noeuds pour OG = $avgN"
