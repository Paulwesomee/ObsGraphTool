Ici,les r�seaux sont d�compos�s en deux sous-r�seaux se partageant un ensemble de transitions.
Les variables BDD sont affect�es aux places relativement aux transitions de l'interface. 
(i.e. des plus proches aux plus loins des transitions de l'interface).
