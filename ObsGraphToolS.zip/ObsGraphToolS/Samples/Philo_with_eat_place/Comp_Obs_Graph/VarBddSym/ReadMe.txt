Ici,les r�seaux sont d�compos�s en deux sous-r�seaux se partageant un ensemble de transitions.
Les variables BDD sont affect�es � des places sym�triques du syst�me 
(i.e. v1--->Idle1, Idle2, v2--->...Eat1,Eat2, ... etc).
