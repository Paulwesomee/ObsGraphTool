#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream.h>
#include <fstream.h>
#include <string>
void Gate();
void train(int N);
int
main(int argc,char **argv)
{	
  int N;

  if (argc!=2) return(-1);
  //if ((N=atoi(argv[1]))<2) return(-1);
  N=atoi(argv[1]);
  char nom[20];
  //fichier interface
  char interface[20];
  sprintf(interface,"../interfacecontroller%d.net",N);
  ofstream g(interface);
  g<<2*N+2<<endl;
  g<<"lower\t raise";

  sprintf(nom,"../controller%d.net",N);
  ofstream f(nom);
  Gate();
  train(N);
  f<<"#place wait4train mk(<..>)"<<endl;
  f<<"#place order_down"<<endl;
  f<<"#place order_up"<<endl;

  f<<"#trans Cwait_1"<<endl;
  f<<"in {wait4train:<..>;}"<<endl;
  f<<"out {wait4train:<..>;}"<<endl;
  f<<"#endtr"<<endl;

  f<<"#trans Cwait_2"<<endl;
  f<<"in {order_down:<..>;}"<<endl;
  f<<"out {order_down:<..>;}"<<endl;
  f<<"#endtr"<<endl;

  f<<"#trans Cwait_3"<<endl;
  f<<"in {order_up:<..>;}"<<endl;
  f<<"out {order_up:<..>;}"<<endl;
  f<<"#endtr"<<endl;
  
  f<<"#trans lower"<<endl;
  f<<"in {order_down:<..>;}"<<endl;
  f<<"out {wait4train:<..>;}"<<endl;
  f<<"#endtr"<<endl;

  f<<"#trans raise"<<endl;
  f<<"in {order_up:<..>;}"<<endl;
  f<<"out {wait4train:<..>;}"<<endl;
  f<<"#endtr"<<endl;

  for(int i=1;i<=N;i++){
    f<<"#trans approach_"<<i<<endl;
    f<<"in {wait4train:<..>;}"<<endl;
    f<<"out {order_down:<..>;}"<<endl;
    f<<"#endtr"<<endl;

    f<<"#trans exit_"<<i<<endl;
    f<<"in {wait4train:<..>;}"<<endl;
    f<<"out {order_up:<..>;}"<<endl;
    f<<"#endtr"<<endl;
    }
    //Compléter le fichier de l'interface
  for(int i=1;i<=N;i++)
  {
   g<<"\t approach_"<<i;
   g<<"\t exit_"<<i;
  }
  cout<<flush;
}
void Gate()
{
   char nom[20];
   char interface[20];
   sprintf(nom,"../gate.net");
   sprintf(interface,"../interfaceGate.net");
   ofstream g(interface);
   g<<"2\n"<<"lower\t raise";
   ofstream f(nom);
   f<<"#place up mk(<..>)"<<endl;
   f<<"#place down"<<endl;
   f<<"#place get_up"<<endl;
   f<<"#place get_down"<<endl;

   f<<"#trans wait_1"<<endl;
   f<<"in {up:<..>;}"<<endl;
   f<<"out {up:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   f<<"#trans wait_2"<<endl;
   f<<"in {get_down:<..>;}"<<endl;
   f<<"out {get_down:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   f<<"#trans wait_3"<<endl;
   f<<"in {down:<..>;}"<<endl;
   f<<"out {down:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   f<<"#trans wait_4"<<endl;
   f<<"in {get_up:<..>;}"<<endl;
   f<<"out {get_up:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   f<<"#trans lower"<<endl;
   f<<"in {up:<..>;}"<<endl;
   f<<"out {get_down:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   f<<"#trans raise"<<endl;
   f<<"in {down:<..>;}"<<endl;
   f<<"out {get_up:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   f<<"#trans open"<<endl;
   f<<"in {get_up:<..>;}"<<endl;
   f<<"out {up:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   f<<"#trans close"<<endl;
   f<<"in {get_down:<..>;}"<<endl;
   f<<"out {down:<..>;}"<<endl;
   f<<"#endtr"<<endl;
 }
 void train(int N)
 {
    char nom[20];
    char interface[20];
    for(int i=1;i<=N;i++)
    {
    //fichier interface
    sprintf(interface, "../interfacetrain%d.net",i);
    ofstream g(interface);
    g<<"2"<<endl;
    g<<"approach_"<<i;
    g<<"\t exit_"<<i;
    sprintf(nom,"../train%d.net",i);
    ofstream f(nom);
    f<<"#place far_"<<i<<" mk(<..>)"<<endl;
    f<<"#place before_"<<i<<endl;
    f<<"#place after_"<<i<<endl;

    f<<"#trans wait_1_"<<i<<endl;
    f<<"in {far_"<<i<<":<..>;}"<<endl;
    f<<"out {far_"<<i<<":<..>;}"<<endl;
    f<<"#endtr"<<endl;

    f<<"#trans wait_2_"<<i<<endl;
    f<<"in {before_"<<i<<":<..>;}"<<endl;
    f<<"out {before_"<<i<<":<..>;}"<<endl;
    f<<"#endtr"<<endl;

    f<<"#trans wait_3_"<<i<<endl;
    f<<"in {after_"<<i<<":<..>;}"<<endl;
    f<<"out {after_"<<i<<":<..>;}"<<endl;
    f<<"#endtr"<<endl;

    f<<"#trans pass_"<<i<<endl;
    f<<"in {before_"<<i<<":<..>;}"<<endl;
    f<<"out {after_"<<i<<":<..>;}"<<endl;
    f<<"#endtr"<<endl;

    f<<"#trans approach_"<<i<<endl;
    f<<"in {far_"<<i<<":<..>;}"<<endl;
    f<<"out {before_"<<i<<":<..>;}"<<endl;
    f<<"#endtr"<<endl;

    f<<"#trans exit_"<<i<<endl;
    f<<"in {after_"<<i<<":<..>;}"<<endl;
    f<<"out {far_"<<i<<":<..>;}"<<endl;
    f<<"#endtr"<<endl;
  }
}
