#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream.h>
#include <fstream.h>
#include <string>
int
main(int argc,char **argv)
{	
  int N;

  if (argc!=2) return(-1);
  //if ((N=atoi(argv[1]))<2) return(-1);
  N=atoi(argv[1]);
  char nom[20];char interf[20];
  sprintf (interf,"../interf%d.net",N);
  //transitions de l'interface
  ofstream g(interf);
  g<<2*N+2<<endl;
  g<<"lower\t raise";
  for(int i=1;i<=N;i++)
    {
      g<<"\t approach_"<<i;
      g<<"\t exit_"<<i;
      }
  sprintf(nom,"../train%d.net",N);
  ofstream f(nom);

  //places de Gate

   f<<"#place up mk(<..>)"<<endl;
   f<<"#place down"<<endl;
   f<<"#place get_up"<<endl;
   f<<"#place get_down"<<endl;
  
  
   //places du controller

   f<<"#place wait4train mk(<..>)"<<endl;
  f<<"#place order_down"<<endl;
  f<<"#place order_up"<<endl;
 
  //places des trains

     for(int i=1;i<=N;i++)
   {
     f<<"#place far_"<<i<<" mk(<..>)"<<endl;
     f<<"#place before_"<<i<<endl;
     f<<"#place after_"<<i<<endl;
     }
  //transitions Gate

   f<<"#trans wait_1"<<endl;
   f<<"in {up:<..>;}"<<endl;
   f<<"out {up:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   f<<"#trans wait_2"<<endl;
   f<<"in {get_down:<..>;}"<<endl;
   f<<"out {get_down:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   f<<"#trans wait_3"<<endl;
   f<<"in {down:<..>;}"<<endl;
   f<<"out {down:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   f<<"#trans wait_4"<<endl;
   f<<"in {get_up:<..>;}"<<endl;
   f<<"out {get_up:<..>;}"<<endl;
   f<<"#endtr"<<endl;
   
   f<<"#trans open"<<endl;
   f<<"in {get_up:<..>;}"<<endl;
   f<<"out {up:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   f<<"#trans close"<<endl;
   f<<"in {get_down:<..>;}"<<endl;
   f<<"out {down:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   //synchro Gate Controller

   f<<"#trans lower"<<endl;
   f<<"in {up:<..>;order_down:<..>;}"<<endl;
   f<<"out {get_down:<..>;wait4train:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   f<<"#trans raise"<<endl;
   f<<"in {down:<..>;order_up:<..>;}"<<endl;
   f<<"out {get_up:<..>;wait4train:<..>;}"<<endl;
   f<<"#endtr"<<endl;

  
   //transitions controller

   f<<"#trans Cwait_1"<<endl;
   f<<"in {wait4train:<..>;}"<<endl;
   f<<"out {wait4train:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   f<<"#trans Cwait_2"<<endl;
   f<<"in {order_down:<..>;}"<<endl;
   f<<"out {order_down:<..>;}"<<endl;
   f<<"#endtr"<<endl;

   f<<"#trans Cwait_3"<<endl;
   f<<"in {order_up:<..>;}"<<endl;
   f<<"out {order_up:<..>;}"<<endl;
   f<<"#endtr"<<endl;
  
  //synchro Controller trains

   for(int i=1;i<=N;i++){
    f<<"#trans approach_"<<i<<endl;
    f<<"in {wait4train:<..>;far_"<<i<<":<..>;}"<<endl;
    f<<"out {order_down:<..>;before_"<<i<<":<..>;}"<<endl;
    f<<"#endtr"<<endl;

    f<<"#trans exit_"<<i<<endl;
    f<<"in {wait4train:<..>;after_"<<i<<":<..>;}"<<endl;
    f<<"out {order_up:<..>;far_"<<i<<":<..>;}"<<endl;
    f<<"#endtr"<<endl;
  }    
   
  //transitions des trains
  for(int i=1;i<=N;i++){
    
    f<<"#trans wait_1_"<<i<<endl;
    f<<"in {far_"<<i<<":<..>;}"<<endl;
    f<<"out {far_"<<i<<":<..>;}"<<endl;
    f<<"#endtr"<<endl;

    f<<"#trans wait_2_"<<i<<endl;
    f<<"in {before_"<<i<<":<..>;}"<<endl;
    f<<"out {before_"<<i<<":<..>;}"<<endl;
    f<<"#endtr"<<endl;

    f<<"#trans wait_3_"<<i<<endl;
    f<<"in {after_"<<i<<":<..>;}"<<endl;
    f<<"out {after_"<<i<<":<..>;}"<<endl;
    f<<"#endtr"<<endl;

    f<<"#trans pass_"<<i<<endl;
    f<<"in {before_"<<i<<":<..>;}"<<endl;
    f<<"out {after_"<<i<<":<..>;}"<<endl;
    f<<"#endtr"<<endl;
  }
 cout<<flush;
}
