#!/bin/bash
#Ceci est un commentaire
echo ceci est affiché #Un autre commentaire
./ObsGraph Cont1.net Obs_Cont Fplace_Cont 1
