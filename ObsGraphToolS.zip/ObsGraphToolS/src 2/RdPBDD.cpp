/* -*- C++ -*- */
#include <string>
#include <iostream>
#include <set>
#include <vector>
#include <map>
#include <stack>
#include <ext/hash_map>
using namespace std;
#include <math.h>
#include "bvec.h"
#include "RdPBDD.h"
#include <cstdlib>
#include <sstream>
//#include <stdlib>
int NbIt;
int itext,itint;
int MaxIntBdd;
bdd *TabMeta;
int nbmetastate;
double old_size;
const vector<class Place> *vplaces = NULL;
void my_error_handler(int errcode) {
	if (errcode == BDD_RANGE) {
		// Value out of range : increase the size of the variables...
		// but which one???
		bdd_default_errhandler(errcode);
	}
	else {
		bdd_default_errhandler(errcode);
	}
}

/*****************************************************************/
/*                         printhandler                          */
/*****************************************************************/
void printhandler(ostream &o, int var)
{
	o << (*vplaces)[var/2].name;
	if (var%2)
		o << "_p";
}
 
/*****************************************************************/
/*                         class Trans                           */
/*****************************************************************/
Trans::Trans(const bdd& v, bddPair* p, const bdd& r,const bdd& pr, const bdd& pre, const bdd& post): var(v),pair(p),rel(r),prerel(pr),Precond(pre),Postcond(post) {
}
//Franchissement avant
bdd Trans::operator()(const bdd& n) const {
	bdd res = bdd_relprod(n,rel,var);
	res = bdd_replace(res, pair);
	return res;
}
//Franchissement arri�re
bdd Trans::operator[](const bdd& n) const {
	bdd res = bdd_relprod(n,prerel,var);
	res = bdd_replace(res, pair);
	return res;
}

/*****************************************************************/
/*                         class RdPBDD                          */
/*****************************************************************/

RdPBDD::RdPBDD(const net &R, int BOUND,bool init){
    int nbPlaces=R.places.size(), i, domain;
	vector<Place>::const_iterator p;
	
	bvec *v = new bvec[nbPlaces];
	bvec *vp = new bvec[nbPlaces];
	bvec *prec = new bvec[nbPlaces];
	bvec *postc = new bvec[nbPlaces];
	int *idv = new int[nbPlaces];
	int *idvp = new int[nbPlaces];
	int *nbbit = new int[nbPlaces];
	if(!init)
	  bdd_init(1000000,10000);
	// the error handler
	bdd_error_hook((bddinthandler)my_error_handler);
	//_______________
	transitions=R.transitions;
	Observable=R.Observable;
	NonObservable=R.NonObservable;
	Formula_Trans=R.Formula_Trans;
	Final_State=R.Final_State;
	Final_States=R.Final_States;
	transitionName=R.transitionName;
	InterfaceTrans=R.InterfaceTrans;
	Nb_places=R.places.size();
	cout<<"Nombre de places : "<<Nb_places<<endl; 
	cout<<"Derniere place : "<<R.places[Nb_places-1].name<<endl; 
  /* place domain, place bvect, place initial marking and place name */
	// domains	
	i=0;
	for(i=0,p=R.places.begin();p!=R.places.end();i++,p++) {
		if (p->hasCapacity()) {
			domain = p->capacity+1;
		}
		else {
			domain = BOUND+1; // the default domain
		}
		// variables are created one by one (implying contigue binary variables)
		fdd_extdomain(&domain, 1);
		//cout<<"nb created var : "<<bdd_varnum()<<endl;
		fdd_extdomain(&domain, 1);
		//cout<<"nb created var : "<<bdd_varnum()<<endl;
    }

	// bvec
	currentvar = bdd_true();
	for(i=0;i<nbPlaces;i++) {
		nbbit[i] = fdd_varnum(2*i);
		//cout<<"nb var pour "<<2*i<<" = "<<fdd_domainsize(2*i)<<endl;
		v[i]=bvec_varfdd(2*i);
		vp[i]=bvec_varfdd(2*i+1);
		//cout<<"nb var pour "<<2*i+1<<" = "<<fdd_domainsize(2*i+1)<<endl;
		currentvar = currentvar & fdd_ithset(2*i);
	}

	// initial marking 
    M0=bdd_true();
    //cout<<"ici"<<endl;
   	for(i=0,p=R.places.begin();p!=R.places.end();i++,p++)
		{
		  //cout<<"+++++++ i = "<<i<<" et p = "<<p->marking<<endl;
			M0 = M0 & fdd_ithvar(2*i,p->marking);
		}
	//etats finaux
    Set::const_iterator t;
    finalstate=bdd_true();

for(set<Set>::const_iterator k=R.Final_States.begin();!(k==R.Final_States.end());k++)
	  {	
	    for(i=0,p=R.places.begin();p!=R.places.end();i++,p++)
	      {
		int temp=0;
	    
		for(Set::const_iterator h=(*k).begin();!(h==(*k).end());h++)
		  {// cout<<"+++++++ i = "<<i<<" et p = "<<(*p).name<<" et t = "<<R.places[(*h)].name<<endl;
		
		    if (((*p).name).compare(R.places[(*h)].name)==0)
		      temp=1;
	
		  }
	    
		finalstate = finalstate & fdd_ithvar(2*i,temp);
	      }

	  }
	// place names
	vplaces = &R.places;
	fdd_strm_hook(printhandler);


  /* Transition relation */
    for(vector<Transition>::const_iterator t=R.transitions.begin();
	t!=R.transitions.end();t++){
		int np=0;
		bdd rel = bdd_true(), var = bdd_true(),prerel=bdd_true();
		bdd Precond=bdd_true(),Postcond=bdd_true();
		bddPair *p=bdd_newpair();
		
		for(i=0;i<nbPlaces;i++) {
			prec[i]=bvec_con(nbbit[i],0);
			postc[i]=bvec_con(nbbit[i],0);
		}
		// calculer les places adjacentes a la transition t
		// et la relation rel de la transition t
		set<int> adjacentPlace;
		
		// arcs pre
		for(vector< pair<int,int> >::const_iterator it=t->pre.begin();it!=t->pre.end(); it++) {
			adjacentPlace.insert(it->first);
			prec[it->first] = prec[it->first] + bvec_con(nbbit[it->first], it->second);
		}
		// arcs post
		for(vector< pair<int,int> >::const_iterator it=t->post.begin();it!=t->post.end(); it++) {
			adjacentPlace.insert(it->first);
			postc[it->first] = postc[it->first] + bvec_con(nbbit[it->first], it->second);
		}
		// arcs pre automodifiants
		for(vector< pair<int,int> >::const_iterator it=t->preAuto.begin();it!=t->preAuto.end(); it++) {
			adjacentPlace.insert(it->first);
			prec[it->first] = prec[it->first] + v[it->second];
		}
		// arcs post automodifiants
		for(vector< pair<int,int> >::const_iterator it=t->postAuto.begin();it!=t->postAuto.end(); it++) {
			adjacentPlace.insert(it->first);
			postc[it->first] = postc[it->first] + v[it->second];
		}
		// arcs reset
		for(vector<int>::const_iterator it=t->reset.begin();it!=t->reset.end(); it++) {
			adjacentPlace.insert(*it);
			prec[*it] = prec[*it] + v[*it];
		}
		
		np=0;
		for(set<int>::const_iterator it=adjacentPlace.begin();it!=adjacentPlace.end(); it++) {
			idv[np]=2*(*it);
			idvp[np]=2*(*it)+1;
			var = var & fdd_ithset(2*(*it));
			//Image
			// precondition
			rel = rel & (v[*it] >= prec[*it]);
			Precond = Precond & (v[*it] >= prec[*it]);
			// postcondition
			rel = rel & (vp[*it] == (v[*it] - prec[*it] + postc[*it]));
			// Pre image __________
			// precondition
			prerel = prerel & (v[*it] >= postc[*it]);
			// postcondition
			Postcond=Postcond & (v[*it]>=postc[*it]);
			prerel = prerel & (vp[*it] == (v[*it] - postc[*it] + prec[*it]));
			//___________________
			// capacit�
			if (R.places[*it].hasCapacity())
				rel = rel & (vp[*it] <= bvec_con(nbbit[*it], R.places[*it].capacity));
			np++;
		}
		fdd_setpairs(p, idvp, idv, np);
		
		// arcs inhibitor
		for(vector< pair<int,int> >::const_iterator it=t->inhibitor.begin();it!=t->inhibitor.end(); it++)
			rel = rel & (v[it->first]< bvec_con(nbbit[it->first], it->second));
	
		relation.push_back(Trans(var, p, rel,prerel,Precond,Postcond));
    }
	delete [] v;
	delete [] vp;
	delete [] prec;
	delete [] postc;
	delete [] idv;
	delete [] idvp;
	delete [] nbbit;
}
/*----------------------------------- Reachability space using bdd ----------*/
bdd RdPBDD:: ReachableBDD1()
{
  bdd M1;
  bdd M2=M0;
  double d,tps;
  d=(double)clock() / (double)CLOCKS_PER_SEC;
  NbIt=0;
  MaxIntBdd=bdd_nodecount(M0);
  while(M1!=M2){
		M1=M2; 	
		for(vector<Trans>::const_iterator i = relation.begin();
				i!=relation.end();i++) {
			bdd succ = (*i)(M2);
			M2=succ|M2;
			//cout << bdd_nodecount(succ) << endl;
			//if(succ!=bddfalse)
		}
		NbIt++;
		int Current_size=bdd_nodecount(M2);
		if(MaxIntBdd<Current_size)
		  MaxIntBdd=Current_size;
		//cout<<"Iteration numero "<<NbIt<<" nb node de reached :"<<bdd_nodecount(M2)<<endl;		
//		cout << bdd_nodecount(M2) << endl;
	}
	cout << endl;
	tps = ((double)(clock()) / CLOCKS_PER_SEC) - d;
	cout<<"-----------------------------------------------------\n";
	cout << "CONSTRUCTION TIME  " << tps << endl;
	cout<<"Max Intermediary BDD "<<MaxIntBdd<<endl;
	cout<<"Nombre d'iteration : "<<NbIt<<endl;
	//bdd Cycle=EmersonLey(M2,0);
	//cout<<Cycle.id()<<endl;
	return M2;
}
bdd RdPBDD:: ReachableBDD2()
{
    bdd M1;
  bdd M2=M0;
  double d,tps;
  d=(double)clock() / (double)CLOCKS_PER_SEC;
  NbIt=0;
  MaxIntBdd=bdd_nodecount(M0);
  while(M1!=M2){
		M1=M2; 	
		bdd Reached;
		for(vector<Trans>::const_iterator i = relation.begin();
				i!=relation.end();i++) {
			bdd succ = (*i)(M2);
			Reached=succ|Reached;
			//cout << bdd_nodecount(succ) << endl;
			//if(succ!=bddfalse)
		}
		NbIt++;
		M2=M2|Reached;
		int Current_size=bdd_nodecount(M2);
		if(MaxIntBdd<Current_size)
		  MaxIntBdd=Current_size;
		//cout<<"Iteration numero "<<NbIt<<" nb node de reached :"<<bdd_nodecount(M2)<<endl;		
//		cout << bdd_nodecount(M2) << endl;
	}
	cout << endl;
	tps = ((double)(clock()) / CLOCKS_PER_SEC) - d;
	cout<<"-----------------------------------------------------\n";
	cout << "CONSTRUCTION TIME  " << tps << endl;
	cout<<"Max Intermediary BDD "<<MaxIntBdd<<endl;
	cout<<"Nombre d'iteration : "<<NbIt<<endl;
	return M2;
}
bdd RdPBDD:: ReachableBDD3()
{
  double d,tps;
  d=(double)clock() / (double)CLOCKS_PER_SEC;
	bdd New,Reached,From;
	Reached=From=M0;
	NbIt=0;
	do{    
	  NbIt++;
	     bdd succ;		
	     for(vector<Trans>::const_iterator i = relation.begin();	   	i!=relation.end();i++) 
		 succ=(*i)(From)|succ;
  	    New=succ-Reached;
	    From=New;
	    Reached=Reached | New;
	    cout<<"Iteration numero "<<NbIt<<" nb node de reached :"<<bdd_nodecount(Reached)<<endl;		
	}while(New!=bddfalse);
	tps=(double)clock() / (double)CLOCKS_PER_SEC-d;
	cout << "TPS CONSTRUCTION : "<<tps<<endl;
	return Reached;
}
/*----------------Fermeture transitive sur les transitions non observ�es ---*/
bdd RdPBDD::Accessible_epsilon2(bdd Init)
{
 
  bdd Reached,New,From;
  Reached=From=Init;
  do{    
       bdd succ;		
	for(Set::const_iterator i=NonObservable.begin();!(i==NonObservable.end());i++)
       
		 succ= relation[(*i)](From)|succ;
  	    New=succ-Reached;    
	    From=New;
	    Reached=Reached | New;		     
	}while(New!=bddfalse);
	cout << endl;
	return Reached;
}
bdd RdPBDD::Accessible_epsilon(bdd From)
{
  bdd M1;
  bdd M2=From;
  int it=0;
  do{  
        M1=M2;
	for(Set::const_iterator i=NonObservable.begin();!(i==NonObservable.end());i++)
	  {
       
	    bdd succ= relation[(*i)](M2);	 
	    M2=succ|M2;
	  }	  
	TabMeta[nbmetastate]=M2;
	int intsize=bdd_anodecount(TabMeta,nbmetastate+1);
	if(MaxIntBdd<intsize)
	    MaxIntBdd=intsize;	
	it++;
	//	cout << bdd_nodecount(M2) << endl;
  }while(M1!=M2);
  //cout << endl;
	return M2;
}
/*------------------------  StepForward()  --------------*/
bdd RdPBDD::StepForward2(bdd From)
{
  // cout<<"Debut Step Forward \n";
  bdd Res;
  for(Set::const_iterator i=NonObservable.begin();!(i==NonObservable.end());i++)
  {
       bdd succ = relation[(*i)](From);
       Res=Res|succ;
  }
  //cout<<"Fin Step Forward \n";
  return Res;
}
bdd RdPBDD::StepForward(bdd From)
{
  //cout<<"Debut Step Forward \n";
  bdd Res=From;
  for(Set::const_iterator i=NonObservable.begin();!(i==NonObservable.end());i++)
  {
       bdd succ = relation[(*i)](Res);
       Res=Res|succ;
  }
  //cout<<"Fin Step Forward \n";
  return Res;
}
/*------------------------  StepBackward()  --------------*/
bdd RdPBDD::StepBackward2(bdd From)
{
  bdd Res;
  cout<<"Ici Step Back : From.id() = "<<From.id()<<endl;
   for(vector<Trans>::const_iterator t=relation.begin();
	t!=relation.end();t++){
       bdd succ = (*t)[From];
       Res=Res|succ;
  }
  cout<<"Res.id() = "<<Res.id()<<endl;
  return Res;
}
bdd RdPBDD::StepBackward(bdd From)
{
  bdd Res=From;
   for(vector<Trans>::const_iterator t=relation.begin();
	t!=relation.end();t++){
       bdd succ = (*t)[Res];
       Res=Res|succ;
  }
  return Res;
}
/*---------------------------GetSuccessor()-----------*/
bdd RdPBDD::get_successor(bdd From,int t)
{
  return relation[t](From);
}
/*-------------------------Firable Obs()--------------*/
Set RdPBDD::firable_obs(bdd State)
{
  Set res;
  for(Set::const_iterator i=Observable.begin();!(i==Observable.end());i++)
  {
	{bdd succ =  relation[(*i)](State);
	if(succ!=bddfalse)
	  res.insert(*i);}
   }
  return res;
}

/*------------------------------------Observation Graph ----------*/
void  RdPBDD::compute_canonical_deterministic_graph_Opt(MDGraph& g) 
{
  cout<<"COMPUTE CANONICAL DETERMINISTIC GRAPH_________________________ \n";
  //cout<<"nb bdd var : "<<bdd_varnum()<<endl;
  double d,tps;
  d=(double)clock() / (double)CLOCKS_PER_SEC;
  TabMeta=new bdd[100];
  nbmetastate=0;
  MaxIntBdd=0;
  typedef pair<Class_Of_State*,bdd> couple;
  typedef pair<couple, Set> Pair;
  typedef stack<Pair> pile;
  pile st;
  NbIt=0;
  itext=itint=0;
   Class_Of_State* reached_class;
   Set fire;
   // size_t max_meta_state_size;
   Class_Of_State *c=new Class_Of_State;
   {
     // cout<<"Marquage initial :\n";
     //cout<<bddtable<<M0<<endl;
     //cout<<"FIN marquage initial :\n";
     //cout<<"Etat Fianux :\n";
     //cout<<bddtable<<finalstate<<endl;
     //cout<<"FIN Etat Finaux :\n";

     bdd Complete_meta_state=Accessible_epsilon(M0);  
     //cout<<"Apres accessible epsilon \n";
     fire=firable_obs(Complete_meta_state);
     //  c->blocage=Set_Bloc(Complete_meta_state);
     c->boucle=Set_Div(Complete_meta_state);
     c->final=((Complete_meta_state & finalstate)!=bdd_false());
     //  cout<<"**************Compute LAMDA:************** "<<endl;
     //  cout<<"--------------------"<<endl;
     c->lamda=computelamda(Complete_meta_state,c->final,Set_Bloc(Complete_meta_state));
     // cout<<"**************Apres computing LAMDA*******"<<endl;
     //cout<<"--------------------"<<endl<<endl;

     /* cout<<"hhhh:1111  "<<c->final<<endl;
     cout<<"Complete_meta_state :\n";
     cout<<bddtable<<Complete_meta_state<<endl;
     cout<<"FIN Complete_meta_state :\n";
     cout<<"finalstate :\n";*/
     // cout<<bddtable<<finalstate<<endl;
     // cout<<"FIN finalstate :\n";
     c->class_state=CanonizeR(Complete_meta_state,0);
     //  cout<<"Apres CanonizeR nb representant : "<<bdd_pathcount(c->class_state)<<endl;
     //c->class_state=Complete_meta_state;  
     TabMeta[nbmetastate]=c->class_state;
     nbmetastate++;
     old_size=bdd_nodecount(c->class_state);
     //max_meta_state_size=bdd_pathcount(Complete_meta_state);
     st.push(Pair(couple(c,Complete_meta_state),fire));
   }
    g.setInitialState(c);
   g.insert(c);
   g.nbMarking+=bdd_pathcount(c->class_state);
   do
   {
     Pair  e=st.top();  
     st.pop();
     nbmetastate--;
     while(!e.second.empty()) 
     { 
	int t = *e.second.begin();
	//cout<<"t:\n"<<t;
	e.second.erase(t);
	double nbnode;
	reached_class=new Class_Of_State;
	{
	  // cout<<"Avant Accessible epsilon \n";
	  bdd Complete_meta_state=Accessible_epsilon(get_successor(e.first.second,t));
	  //cout<<"Apres accessible epsilon \n";
	  //cout<<"Avant CanonizeR \n";
	  reached_class->class_state=CanonizeR(Complete_meta_state,0);
	  //cout<<"Apres CanonizeR \n";
	  // cout<<"Apres CanonizeR nb representant : "<<bdd_pathcount(reached_class->class_state)<<endl;
	  //reached_class->class_state=Complete_meta_state;
	  Class_Of_State* pos=g.find(reached_class);
	  nbnode=bdd_pathcount(reached_class->class_state);
	  if(!pos)
	  {
	    // reached_class->blocage=Set_Bloc(Complete_meta_state);
	    reached_class->boucle=Set_Div(Complete_meta_state);
	    reached_class->final=((Complete_meta_state & finalstate)!=bdd_false());
	    // cout<<"**************Compute LAMDA:************** "<<endl;
	    cout<<"--------------------"<<endl;
	    reached_class->lamda=computelamda(Complete_meta_state,reached_class->final,(Set_Bloc(Complete_meta_state)));
	    //  cout<<"**************Apres computing LAMDA*******"<<endl;
	    //cout<<"--------------------"<<endl<<endl;

	    /*cout<<"hhhh: "<<reached_class->final<<endl;
	      cout<<"Complete_meta_state :\n";
	      cout<<bddtable<<Complete_meta_state<<endl;
	      cout<<"FIN Complete_meta_state :\n";
	      cout<<"finalstate :\n";
	      cout<<bddtable<<finalstate<<endl;
	      cout<<"FIN finalstate :\n";*/
	    fire=firable_obs(Complete_meta_state);
	    st.push(Pair(couple(reached_class,Complete_meta_state),fire));
	    TabMeta[nbmetastate]=reached_class->class_state;
	    nbmetastate++;
	    old_size=bdd_anodecount(TabMeta,nbmetastate);
	    e.first.first->Successors.insert(e.first.first->Successors.begin(),Edge(reached_class,t));	   
	    reached_class->Predecessors.insert(reached_class->Predecessors.begin(),Edge(e.first.first,t));
	    g.addArc();
	    g.insert(reached_class);
	  }
	  else
	  {
	    delete reached_class;
	    e.first.first->Successors.insert(e.first.first->Successors.begin(),Edge(pos,t));
	    pos->Predecessors.insert(pos->Predecessors.begin(),Edge(e.first.first,t));
	    g.addArc();
	  }
	}
	  
     }		
  } while(!st.empty());
   tps=(double)clock() / (double)CLOCKS_PER_SEC-d;
   cout<<"TIME OF CONSTRUCTIONR : "<<tps<<endl;
   cout<<" MAXIMAL INTERMEDIARY BDD SIZE \n"<<MaxIntBdd<<endl;
   cout<<"OLD SIZE : "<<old_size<<endl;
   //cout<<"NB SHARED NODES : "<<bdd_anodecount(TabMeta,nbmetastate)<<endl;
   cout<<"NB META STATE DANS CONSTRUCTION : "<<nbmetastate<<endl;
   cout<<"NB ITERATIONS CONSTRUCTION : "<<NbIt<<endl;
   cout<<"Nb Iteration externes : "<<itext<<endl;
   cout<<"Nb Iteration internes : "<<itint<<endl;
}

/******************computelamda()****************/
set<string> RdPBDD::computelamda(bdd s,bool final,bool bloc)
{
  //cout<<"je suis dans la fonction et bloc= "<<bloc<<endl;
  map<string,bdd> Res;
    int nb=0;
  if(final)
    {
      bool test= true;
      bdd p= bdd_true();
      p=StepForward(s & finalstate);
   while(test)
	{   if(p==StepForward(s & p))
	 
	      test=false;
	  
	   else
	      p=StepForward(s & p);
	}
	Res.insert(make_pair("term",p));
	nb++;
   }

      Set Obs=firable_obs(s);
   
      for(Set::const_iterator i= Obs.begin();!(i==Obs.end());i++)
	{
	  bdd temp=FrontiereNodes2(s,(*i));
	  // cout<<"FrontiereNodes2 :"<<endl;
	  //cout<<bddtable<<temp;
	  //

	   int a=(*i);
	   std::ostringstream os;
	  os<<a;
	  //  string s = os.str();

	   Res.insert(make_pair(transitions[a].name,temp));
     		     nb++;
	 }
	 for (map<string,bdd>::const_iterator i= Res.begin();(i!=Res.end());i++)
	       for (map<string,bdd>::const_iterator j= Res.begin();(j!=i);j++)
		  {
		    if ((*i).second==(*j).second)
		       {
			 j=i;
			 /* if((*i).first.compare("term"))
			 {			
			   std::istringstream iss((*i).first);
			   iss >> nombre;
			   Res.insert(make_pair(transitions[nombre].name+","+(*j).first,(*i).second));
		
			 }
			 else*/
			   Res.insert(make_pair((*i).first+","+(*j).first,(*i).second));
			 Res.erase((*i).first);
		        }
		    }

		 if(bloc)
		 Res.insert(make_pair("EV",bddfalse));
		   set<string> lamda;
		   for (map<string,bdd>::const_iterator i= Res.begin();(i!=Res.end());i++)
		     {
		      lamda.insert((*i).first);
		     }
	  //affichage de lamda 
		      cout<<"    LAMDA : "<<endl;
		  cout<<"{";
	
		  for(set<string>::const_iterator i=lamda.begin();i!=lamda.end();i++)
		     { 
		       string cr=(*i); 
		       /*	while(cr.find(",")!=-1)
			  {
			    string h=cr.substr(0,cr.find(","));
			    cr=cr.substr(cr.find(",")+1);
			    int nombre;	*/	      
			 
			 cout<<"{"<<cr<<"}";

			 // }
		      
		     }
		     cout<<"}"<<endl;
		   return lamda;
}

/*-----------------------CanonizeR()----------------*/
bdd RdPBDD::CanonizeR(bdd s, unsigned int i)
 {
   bdd s1,s2;
   do
   {
	itext++;
   	s1 = s - bdd_nithvar(2*i);
   	s2 = s - s1;
   	if((!(s1==bddfalse))&&(!(s2==bddfalse)))
   	{
   		bdd front = s1;
   		bdd reached = s1;
   		do
   		{
		  //cout<<"premiere boucle interne \n";
   		    itint++;
   		    front=StepForward(front) - reached;
   		    reached = reached | front;
   		    s2 = s2 - front;
   		}while((!(front==bddfalse))&&(!(s2==bddfalse)));
   	}
   	if((!(s1==bddfalse))&&(!(s2==bddfalse)))
   	{
   		bdd front=s2;
   		bdd reached = s2;
   		do
   		{
		  // cout<<"deuxieme boucle interne \n";
		   itint++;
   		   front=StepForward(front) - reached;
   		   reached = reached | front;
   		   s1 = s1 - front;
   		}while((!(front==bddfalse))&&(!(s1==bddfalse)));
   	}
   	s=s1 | s2;
  	i++;
  }while((i<Nb_places) &&((s1==bddfalse)||(s2==bddfalse)));
  if(i>=Nb_places)
   {
     //cout<<"____________oooooooppppppppsssssssss________\n";
       return s;
   }
  else
    {
      //cout<<"________________p a s o o o p p p s s s ______\n";
      return(CanonizeR(s1,i) | CanonizeR(s2,i));
    }
}
/*---------------------------  Set_Bloc()  -------*/
bool RdPBDD::Set_Bloc(bdd &S) const
{	
  //cout<<"Ici detect blocage \n";
	int k=0;
	bdd Mt=bddtrue;		            
	  for(vector<Trans>::const_iterator i = relation.begin();	   	i!=relation.end();i++,k++) 		 
	  {
	    //cout<<"transition :"<<transitions[k].name<<endl;
	     // cout<<"PRECOND :"<<bddtable<<(*i).Precond<<endl;
	     //cout<<"POSTCOND :"<<bddtable<<(*i).Postcond<<endl;
	    //int toto;cin>>toto;
		Mt=Mt & !((*i).Precond);	
	   }
	  // cout<<"finalstate :"<<bddtable<<finalstate<<endl;
	  //  cout<<"S :"<<bddtable<<S<<endl;
	  //  cout<<"MT :"<<bddtable<<(Mt )<<endl;

	  // cout<<"MT& S :"<<bddtable<<(Mt & finalstate)<<endl;
	  // cout<<"res bool :"<<(((S&Mt))!=bddfalse)<<endl;
	    return ((((S&Mt))!=bddfalse)&&((S&Mt)!=finalstate));
		//BLOCAGE
}


/*-------------------------Set_Div() � revoir -----------------------------*/
bool RdPBDD::Set_Div(bdd &S) const
{
	Set::const_iterator i;
	bdd To,Reached;
	//cout<<"Ici detect divergence \n";
	Reached=S;
	do
	{
	        bdd From=Reached;
		for(i=NonObservable.begin();!(i==NonObservable.end());i++)
		{

				To=relation[*i](Reached);
				Reached=Reached|To; //Reached=To ???
				//Reached=To;
		}
		if(Reached==From)
			//cout<<"SEQUENCE DIVERGENTE \n";
			return true;
		//From=Reached;
	}while(Reached!=bddfalse);
	 return false;
	//cout<<"PAS DE SEQUENCE DIVERGENTE \n";
}

/*-----------FrontiereNodes() pour bdd ---------*/
bdd RdPBDD::FrontiereNodes(bdd From) const 
{	
	bdd res=bddfalse;
	for(Set::const_iterator i=Observable.begin();!(i==Observable.end());i++)     
			res=res | (From & relation[*i].Precond);
	for(Set::const_iterator i=InterfaceTrans.begin();!(i==InterfaceTrans.end());i++)     
			res=res | (From & relation[*i].Precond);
	return res;
}
/*-----------FrontiereNodes2() pour bdd ---------*/
bdd RdPBDD::FrontiereNodes2(bdd From,int i) const 
{	
	bdd res=bddfalse;
   
			res=res | (From & relation[i].Precond);

	return res;
}
/*-------- Produit synchronis� � la vol�e de n graphes d'observation : Adaptation � la capture des s�quences bloquantes et les s�quences divergentes----------------------*/
void RdPBDD::GeneralizedSynchProduct1(Modular_Obs_Graph& Gv, int NbSubnets,RdPBDD* Subnets[] ,int nbbddvar) 
{
    cout<<"_____________  GeneralizedSynchProduct1  _________________________"<<NbSubnets<<"sous-reseaux "<<endl;
    //for(int k=0;k<NbSubnets;k++)
    //	cout<<*Subnets[k]<<endl;
   int pos_trans(TRANSITIONS,string);
   TabMeta=new bdd[1000000];
   nbmetastate=0;
   MaxIntBdd=0;
   nbmetastate=0;
   Stack st;
   //int cpt=0;
   int k;
   bdd *Complete_meta_state=new bdd[NbSubnets];
   Set *fire=new Set[NbSubnets];
   Modular_Class_Of_State *Meta_State=new Modular_Class_Of_State;
   for(k=0;k<NbSubnets;k++)
     {
	Complete_meta_state[k]=Subnets[k]->Accessible_epsilon(Subnets[k]->M0);
	fire[k]=Subnets[k]->firable_obs(Complete_meta_state[k]);
	//	Meta_State->final=((Complete_meta_state[k]& Subnets[k].finalstate)!=bdd_false());
	//Meta_State->State.push_back(Subnets[k]->FrontiereNodes(Complete_meta_state[k]));
	//Meta_State->State.push_back(Subnets[k]->CanonizeR(Subnets[k]->FrontiereNodes(Complete_meta_state[k]),0));
	Meta_State->State.push_back(Subnets[k]->CanonizeR(Complete_meta_state[k],0));
	//	Meta_State->lamda=Subnets[k]->computelamda(Complete_meta_state[k],Meta_State->final,Subnets[k]->Set_Div(Complete_meta_state[k]));
	/*-------------------- STAT ----------------------*/
	TabMeta[nbmetastate]=Meta_State->State[k];
	nbmetastate++;
     }	
   old_size=bdd_anodecount(TabMeta,nbmetastate);
   Meta_State->blocage=true;
   for( k=0;((k<NbSubnets)&&(Meta_State->blocage));k++)
   Meta_State->blocage=Meta_State->blocage&&Subnets[k]->Set_Bloc(Complete_meta_state[k]);
   Meta_State->boucle=false;
   for(k=0;((k<NbSubnets)&&(!Meta_State->boucle));k++)
     Meta_State->boucle=Meta_State->boucle||Subnets[k]->Set_Div(Complete_meta_state[k]);
   Meta_State->final=false;
   for(int j=0;((j<NbSubnets)&&(!Meta_State->final));j++)
     Meta_State->final|=((Complete_meta_state[j]&Subnets[j]->finalstate)!=bdd_false());
   cout<<"final 1 = "<< Meta_State->final<<endl;
   // set<string> res;
   // res=Subnets[0]->computelamda(Complete_meta_state[0],Meta_State->final,true);
   set<string>  lamdas[NbSubnets];
   //   vector<set<string> >::iterator it= lamdas.begin();
   for(k=0;k<NbSubnets;k++)
     {
       lamdas[k]=Subnets[k]->computelamda(Complete_meta_state[k],Meta_State->final,false);
     }
   // Meta_State->lamda=Subnets[0]->computelamdaSyncro(lamdas,NbSubnets);
   Meta_State->lamda=Gv.computelamdaSyncro(lamdas,NbSubnets);

   Gv.setInitialState(Meta_State);		   
   Gv.insert(Meta_State);
   nbmetastate++;
   st.push(StackElt(Couple(Meta_State,Complete_meta_state),fire));  
   do
     { //cout<<"nbit ="<<NbIt<<endl;
       NbIt++;
      
       StackElt e=st.top();
       st.pop();	
       for(k=0;k<NbSubnets;k++)
	 {
	   while(!e.second[k].empty())
	     {
	       int t=*e.second[k].begin();	
	       e.second[k].erase(t);
	       bool ok=true;
	       Set ConcernedSubnets;
	       ConcernedSubnets.insert(k);
	       string tmp=Subnets[k]->transitions[t].name;
	       for(int j=0;j<NbSubnets;j++)
		 {
		   if(j!=k)
		     {
		       int num=Subnets[j]->transitionName[tmp];		
		       int pos=pos_trans(Subnets[j]->transitions,tmp);
		       if((pos!=-1)&&!(Subnets[j]->Observable.find(num)==Subnets[j]->Observable.end()))
			 {							
			   ConcernedSubnets.insert(j);
			   if(e.second[j].find(num)==e.second[j].end())
			     ok=false;
			   else
			     e.second[j].erase(num);
			 }				
		     }
		 }
	       if(ok)
		 {
		   Complete_meta_state=new bdd[NbSubnets];
		   fire=new Set[NbSubnets];
		   Meta_State=new Modular_Class_Of_State;
		   for(int j=0;j<NbSubnets;j++)
		     {
		       if(ConcernedSubnets.find(j)==ConcernedSubnets.end())
			 {
			   Complete_meta_state[j]=e.first.second[j];		
			   Meta_State->State.push_back(e.first.first->State[j]);
			 }
		       else
			 {											
			   Complete_meta_state[j]=Subnets[j]->Accessible_epsilon(Subnets[j]->get_successor(e.first.second[j],Subnets[j]->transitionName[tmp])); 
			   //Point de sortie
			   //Meta_State->State.push_back(Subnets[j]->FrontiereNodes(Complete_meta_state[j]));
			   //Meta_State->State.push_back(Subnets[j]->CanonizeR(Subnets[j]->FrontiereNodes(Complete_meta_state[j]),0));
			   Meta_State->State.push_back(Subnets[j]->CanonizeR(Complete_meta_state[j],0));
			   /*-------------------- STAT ----------------------*/
			   TabMeta[nbmetastate]=Meta_State->State[k];
			   nbmetastate++;
			 }
		       fire[j]=Subnets[j]->firable_obs(Complete_meta_state[j]);
		     }
		   Modular_Class_Of_State * pos=Gv.find(Meta_State);
		   if(!pos)
		     {		
		       old_size=bdd_anodecount(TabMeta,nbmetastate);
		       //Calcul de deadlock et loop attributes
		       Meta_State->blocage=true;
		       for(int j=0;((j<NbSubnets)&&(Meta_State->blocage));j++)
			 Meta_State->blocage&=Subnets[j]->Set_Bloc(Complete_meta_state[j]);
		       Meta_State->boucle=false;
		       for(int j=0;((j<NbSubnets)&&(!Meta_State->boucle));j++)
			 Meta_State->boucle|=Subnets[j]->Set_Div(Complete_meta_state[j]);
		       Meta_State->final=false;
		       for(int j=0;((j<NbSubnets)&&(!Meta_State->final));j++)
			 Meta_State->final|=((Complete_meta_state[j]&Subnets[j]->finalstate)!=bdd_false());
		       //   cout<<"final = "<< Meta_State->final<<endl;
		       set<string>  lamdas[NbSubnets];
		        for(int g=0;g<NbSubnets;g++)
			 {
			   lamdas[g]=Subnets[g]->computelamda(Complete_meta_state[g],Meta_State->final,false);
			   }
			//  Meta_State->lamda=Subnets[0]->computelamdaSyncro(lamdas,NbSubnets);
			   Meta_State->lamda=Gv.computelamdaSyncro(lamdas,NbSubnets);
			 
		        /*    set<string>  glamdas[2];
		       set<string>  l;
		       l.insert("term");
		       l.insert("pspec");
		      
		         set<string>  l1; 
			 l1.insert("pcost");
		        glamdas[0]=l1;
			glamdas[1]=l;
			Meta_State->lamda=Subnets[0]->computelamdaSyncro(glamdas,2);*/
		       st.push(StackElt(Couple(Meta_State,Complete_meta_state),fire));
		       e.first.first->Successors.insert(e.first.first->Successors.begin(),Modular_Edge(Meta_State,tmp));
		       Meta_State->Predecessors.insert(Meta_State->Predecessors.begin(),Modular_Edge(e.first.first,tmp));
		       Gv.addArc();
		       Gv.insert(Meta_State);
		  
							
		     }
		   else
		     {
		       e.first.first->Successors.insert(e.first.first->Successors.begin(),Modular_Edge(pos,tmp));
		       pos->Predecessors.insert(pos->Predecessors.begin(),Modular_Edge(e.first.first,tmp));
		       Gv.addArc();
		       delete Meta_State;
		    //Neoud d�ja rencontr� ;
		     }
		   //Demander, en cas d'un blocage, si on veut terminer la consruction de GO
		   set<string>::const_iterator t;
		   t=Meta_State->lamda.find("EV");
		   if(t!=Meta_State->lamda.end())
			     {
			       cout<<"\n\tDEADLOCK !!!"<<endl; 
			       cout<<" \n\nCOMPLETE GRAPH'S BUILDING ?(y/n)"<<endl;
			       char c;
			       cin>>c;
			       if(c=='n'||c=='N')
				 {
				   cout<<"No"<<endl;
				   size_t n=1;
				   Gv.printGraph(Gv.initialstate,n);
				   exit(0);
				 }
			      
			     }
		 } 
	 
	     }

	}

     }while(!st.empty());
   cout<<" MAXIMAL INTERMEDIARY BDD SIZE \n"<<MaxIntBdd<<endl;
   cout<<"OLD SIZE : "<<bdd_anodecount(TabMeta,nbmetastate)<<endl;
   cout<<"NB SHARED NODES : "<<bdd_anodecount(TabMeta,nbmetastate)<<endl;
   cout<<"NB META STATE DANS CONSTRUCTION : "<<nbmetastate<<endl;
   cout<<"NB ITERATIONS CONSTRUCTION : "<<NbIt<<endl;
   cout<<"NB ITERATIONS EXTERNES : "<<itext<<endl;
   cout<<"NB ITERATIONS INTERNES : "<<itint<<endl;
}


/*------------------------EmersonLey ----------------------------*/
bdd RdPBDD::EmersonLey(bdd S,bool trace) 
{
	cout<<"ICI EMERSON LEY \n";
	double		TpsInit, TpsDetect;
	double debitext,finitext;
	TpsInit = (double)(clock()) / CLOCKS_PER_SEC;
	bdd b=S;
	bdd Fair=bdd_ithvar(2*Nb_places-1);
	cout<<"PLACE TEMOIN \n";
	//cout<<places[places.size()-1].name<<endl;
	bdd oldb;
	bdd oldd,d;
	int extit=0;
	int init=0;
	do
	{
		
		extit++;
		if(trace)
		{
			
			cout<<"ITERATION EXTERNES NUMERO :"<<extit<<endl;
			debitext=(double)(clock()) / CLOCKS_PER_SEC;
			cout<<"TAILLE DE B AVANT IT INTERNE : "<<bdd_nodecount(b)<<endl;
			cout<<endl<<endl;
		}
		oldb=b;
		//cout<<"Fair : "<<Fair.id()<<endl;
		d=b & Fair;
		//cout<<"d : "<<d.id()<<endl;
		//init=0;
		do
		{
			init++;
			if(trace)
			{
				
				cout<<"ITERATION INTERNES NUMERO :"<<init<<endl;
				cout<<"HEURE : "<<(double)(clock()) / CLOCKS_PER_SEC<<endl;
				cout<<"TAILLE DE D : "<<bdd_nodecount(d)<<endl;
			}
			oldd=d;
			bdd inter=b & StepForward2(d);
			//cout<<"Tille de inter :"<<bdd_nodecount(inter)<<endl;
			d=d | inter;
		}while(!(oldd==d));
		if(trace)
			cout<<"\nTAILLE DE D APRES ITs INTERNES : "<<bdd_nodecount(d)<<endl;
		b=b & StepBackward2(d);
		init++;
		if(trace)
		{
			cout<<"\n\nTAILLE DE B APRES ELEMINER LES PRED DE D : "<<bdd_nodecount(b)<<endl;
			finitext=(double)(clock()) / CLOCKS_PER_SEC;
			cout<<"DUREE DE L'ITERATION EXTERNE NUMERO "<<extit<<"  :  "<<finitext-debitext<<endl;
			cout<<endl<<"_________________________________________________\n\n";
		}
	}while(!(b==oldb));
	cout<<"NOMBRE D'ITERATIONS EXTERNES -----:"<<extit<<endl;
	cout<<"NOMBRE D'ITERATIONS INTERNES -----:"<<init<<endl;
	TpsDetect = ((double)(clock()) / CLOCKS_PER_SEC) - TpsInit;
	cout << "DETECTION DE CYCLE TIME  " << TpsDetect << endl;
	return b;
}

