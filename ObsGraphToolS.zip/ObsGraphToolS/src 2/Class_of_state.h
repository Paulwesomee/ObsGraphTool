#ifndef CLASS_OF_STATE
#define CLASS_OF_STATE
#include "bdd.h"
#include <map>
#include <set>
#include <utility>
#include<vector>
//#include <backward/vector.h>

//#include <ext/hash_map>
using namespace std;

typedef set<int> Set;

class Class_Of_State
{
	public:
		Class_Of_State(){boucle/*=blocage*/=Visited=final=0;}
		Set firable;
		bdd class_state;
		bool boucle; 
		bool blocage(){for(set<string>::const_iterator it=lamda.begin();it!=lamda.end();it++)
{if((*it).find("EV")!=-1)
return true;
else 
return false;
}}
		bool Visited;
		bool final;
		set<string> lamda;
		void * Class_Appartenance;
		vector<pair<Class_Of_State*,int> > Predecessors, Successors;
		pair<Class_Of_State*,int>  LastEdge;
};
typedef pair<Class_Of_State*, int> Edge;
typedef vector<Edge> Edges;
#endif
