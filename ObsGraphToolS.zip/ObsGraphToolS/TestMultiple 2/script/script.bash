#!/bin/bash

res=$(/Users/Hanen/These/hanen/source/tools2012/Outil/ObsGraphToolS/ObsGraph /Users/Hanen/These/hanen/source/tools2012/Outil/ObsGraphToolS/Cont1.net /Users/Hanen/These/hanen/source/tools2012/Outil/ObsGraphToolS/Obs_Cont /Users/Hanen/These/hanen/source/tools2012/Outil/ObsGraphToolS/Fplace_Cont 1)
echo "RES !!!!!!!! $res !!!!!!!!!!!! RES"
if [[ "$res" =~ "TIME OF CONSTRUCTIONR :" ]] ; then echo OK ; fi
test="jhhgTIMEOFCON:5"
#p=`expr length $test`
#echo $p
x=192.168.3.45:678
echo ${x%:*}
chaineZ=Maison
echo ${chaineZ:2:3}
echo $test|cut -f2 -d "TIMEOFCON:"
chaineZ=abcABC123ABCabc

#echo `expr length "$chaineZ" : '.*'`
a1=$(expr $length "$chaineZ" : '.*')
#a=$(expr $substr $chaineZ 1 2)
echo $chaineZ | sed -n "s/[c].*//p" | wc -c
echo "ha $a1"
echo "ja *$a*"
echo $1
cd $1
for i in *
do
if [ -f $i ]
then
echo $i
var1=$(pwd)
var=$i
model="$var1/$i"
lenght=${#var}
nomodel=${var:0:($lenght-4)}
Obs="$var1/Obs/Obs_$nomodel"
echo $Obs
Fplace="$var1/Fplace/Fplace_$nomodel"
echo $Fplace
echo "$model"

let k=$k+1
fi
done
echo "Il y a  $k fichiers  dans $1"