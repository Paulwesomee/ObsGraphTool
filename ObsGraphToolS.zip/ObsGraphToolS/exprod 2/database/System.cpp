states
passive
active
transitions
