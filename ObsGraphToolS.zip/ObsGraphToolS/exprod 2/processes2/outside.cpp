states
state1
state2
state3
state4
state5
state6
state7
transitions
(state1, t1(I) ,state2)
(state2, t2(I) ,state3)
(state3, t3(I) ,state2)
(state2, Sync(J) ,state4)
(state4, t4(I) ,state5)
(state5, t5(I) ,state2)
(state5, t6(I) ,state6)
(state6, t7(I) ,state7)
