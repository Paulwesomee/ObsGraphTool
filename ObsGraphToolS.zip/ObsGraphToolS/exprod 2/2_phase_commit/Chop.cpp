states
free
occupied
transitions
(free, take(I)(I) ,occupied)
(free, take(J)(I) ,occupied)
(occupied, leave(I)(I) ,free)
(occupied, leave(J)(I) ,free)
