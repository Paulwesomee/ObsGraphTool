states
unborn
thinking
takingchops
eating
leavingchops
dead
transitions
(unborn, born(I) ,thinking)
(thinking, take(I)(I) ,takingchops)
(takingchops, take(I)(J) ,eating)
(eating, leave(I)(I) ,leavingchops)
(leavingchops, leave(I)(J) ,thinking)
(eating, die(I) ,dead)
(dead, decompose(I) ,dead)
