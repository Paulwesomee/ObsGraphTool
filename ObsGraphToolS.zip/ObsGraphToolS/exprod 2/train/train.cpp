states
state1
state2
state3
transitions
(state1, attf(I) ,state1)
(state1, app(I) ,state2)
(state2, attn(I) ,state2)
(state2, passer(I) ,state3)
(state3, attp(I) ,state3)
(state3, exit(I) ,state1)
