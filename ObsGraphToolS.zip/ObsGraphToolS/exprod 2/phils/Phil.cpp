states
thinking
eating
transitions
(thinking, take(I) ,eating)
(eating, leave(I) ,thinking)
