states
free
occupied
transitions
(free, take(I) ,occupied)
(free, take(J) ,occupied)
(occupied, leave(I) ,free)
(occupied, leave(J) ,free)
